class TestData:

    chrome_executable_path = "/Users/usamashahid/PycharmProjects/Selenium Drivers"
    firefox_executable_path = "/Users/usamashahid/PycharmProjects/Drivers"


    Base_url = "https://docs.google.com/forms/d/e/1FAIpQLSfSGh4qzssK1gnZ6JEUe1D4E3lmGCelVD0VZgdHs_y7K_U7rA"

    