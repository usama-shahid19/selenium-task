from selenium import webdriver
from selenium.webdriver.common.keys import Keys

driver = webdriver.chrome "\Users\usamashahid\PycharmProjects\Drivers"

